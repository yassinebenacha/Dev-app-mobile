package com.example.tp4deuxactivites;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CODE = 1; // Code pour identifier la réponse

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Récupérer les vues depuis le layout
        EditText editText = findViewById(R.id.editText);
        Button button = findViewById(R.id.button);
        TextView textViewReply = findViewById(R.id.textViewReply);

        // Ajouter un écouteur au clic du bouton
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Récupérer le texte saisi
                String message = editText.getText().toString();

                // Créer un Intent pour lancer la seconde activité
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);

                // Ajouter le message à l'Intent
                intent.putExtra("MSG_KEY", message);

                // Lancer la seconde activité avec attente de résultat
                startActivityForResult(intent, REQUEST_CODE);
            }
        });
    }

    // Gérer la réponse de MainActivity2
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Vérifier si la réponse provient de MainActivity2
        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
            // Récupérer la réponse
            String replyMessage = data.getStringExtra("REPLY_KEY");

            // Afficher la réponse dans le TextView
            TextView textViewReply = findViewById(R.id.textViewReply);
            textViewReply.setText("Réponse : " + replyMessage);
        }
    }
}
