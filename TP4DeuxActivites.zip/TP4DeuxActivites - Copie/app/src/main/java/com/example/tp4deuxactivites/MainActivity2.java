package com.example.tp4deuxactivites;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        // Récupérer les vues
        TextView textView = findViewById(R.id.textViewMessage);
        EditText editTextReply = findViewById(R.id.editTextReply);
        Button buttonReply = findViewById(R.id.buttonReply);

        // Récupérer le message transmis via l'Intent
        String message = getIntent().getStringExtra("MSG_KEY");

        // Afficher le message dans le TextView
        textView.setText("Message reçu : " + message);

        // Définir l'action du bouton pour renvoyer la réponse
        buttonReply.setOnClickListener(v -> {
            // Récupérer le texte saisi par l'utilisateur
            String replyMessage = editTextReply.getText().toString();

            // Créer un Intent pour renvoyer la réponse à MainActivity
            Intent replyIntent = new Intent();
            replyIntent.putExtra("REPLY_KEY", replyMessage);

            // Retourner la réponse à MainActivity
            setResult(RESULT_OK, replyIntent);
            finish(); // Terminer l'activité actuelle
        });
    }
}
